
## This is a GUI overhaul for the Minimap

This is still EARLY ACCESS!! 

What does that mean? 

It can change at any given moment.
There will be much more focus on pushing this to a release candidate rather than adding XYZ feature (features will come later)

This new visual replacement for your minimap



![Gifthing](https://github.com/sbtoonz/BetterMap/raw/master/images/demogif.gif "Cool gif yo")

#KNOWN ISSUES!
??


Please complain here:
https://discord.gg/5gXNxNkUBt


V0.0.1 
Initial release.